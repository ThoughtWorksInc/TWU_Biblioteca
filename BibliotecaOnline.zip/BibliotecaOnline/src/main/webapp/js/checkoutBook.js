import * as dom  from './dom.js';
import * as api from './callServer.js';
import setUpCheckoutBook from './setUpCheckoutBook.js';

setUpCheckoutBook(dom, api);